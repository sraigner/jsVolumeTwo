var i = 0;


do {
  console.log(i);
  i++;
} while (i < 11);


while(i < 11){
  console.log(i);
  i++;
}